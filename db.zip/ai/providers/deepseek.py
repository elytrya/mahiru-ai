"""DeepSeek — тонкая обёртка над OpenAI-совместимым клиентом."""
from ai.providers.openai import DeepSeekProvider

__all__ = ["DeepSeekProvider"]
